package com.aplicacion.envivoapp.adaptadores;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.aplicacion.envivoapp.R;
import com.aplicacion.envivoapp.modelos.Cliente;
import com.aplicacion.envivoapp.modelos.Mensaje;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.ValueEventListener;

import java.util.List;

public class AdapterReciclerMensajeriaCliente extends RecyclerView.Adapter<AdapterReciclerMensajeriaCliente.MensajeCliente> {

    private List<Mensaje> listMensaje;
    private DatabaseReference databaseReference;

    public AdapterReciclerMensajeriaCliente(List<Mensaje> listMensaje, DatabaseReference databaseReference) {
        this.listMensaje = listMensaje;
        this.databaseReference = databaseReference;
    }


    @NonNull
    @Override
    public MensajeCliente onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_list_mensajeria_cliente,null,false);
        return new MensajeCliente(view);
    }

    @Override
    public void onBindViewHolder(@NonNull MensajeCliente holder, int position) {
        Mensaje mensaje = listMensaje.get(position);
        databaseReference.child("Cliente").child(mensaje.getIdcliente()).addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                if(snapshot.exists()){

                    Cliente cliente = snapshot.getValue(Cliente.class); //instanciamos el cliente

                    holder.nombreClienteMensaje.setText(cliente.getNombre());
                    holder.fechaClienteMensaje.setText(mensaje.getFecha().getDate() + "/" +
                            mensaje.getFecha().getMonth() + "/" + mensaje.getFecha().getYear() + " " +
                            mensaje.getFecha().getHours() + ":" + mensaje.getFecha().getMinutes() + ":" +
                            mensaje.getFecha().getSeconds());
                    holder.mensajeClienteMensaje.setText(mensaje.getTexto());

                }else{
                    Log.d("ERROR","error en encontrar el cliente para AdapterMensajeriaCliente");
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });
    }

    @Override
    public int getItemCount() {
        return listMensaje.size();
    }

    public class MensajeCliente extends RecyclerView.ViewHolder {
        //referenciamos los componentes graficos
        TextView nombreClienteMensaje;
        TextView fechaClienteMensaje ;
        TextView mensajeClienteMensaje;
        public MensajeCliente(@NonNull View itemView) {
            super(itemView);

            TextView nombreClienteMensaje = itemView.findViewById(R.id.txtItemNombreMensajeCliente);
            TextView fechaClienteMensaje  = itemView.findViewById(R.id.txtItemFechaMensajeCliente);
            TextView mensajeClienteMensaje = itemView.findViewById(R.id.txtItemMensajeCliente);


        }

    }

}
