package com.aplicacion.envivoapp.utilidades;

import android.os.Bundle;

public class RetornoParametroCliente {

    public interface RetornoPrametro{
        void parametro(Bundle parametro);
    }
}
