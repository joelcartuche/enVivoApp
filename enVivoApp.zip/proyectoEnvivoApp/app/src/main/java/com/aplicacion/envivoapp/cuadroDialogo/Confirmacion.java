package com.aplicacion.envivoapp.cuadroDialogo;

public class Confirmacion {
}
